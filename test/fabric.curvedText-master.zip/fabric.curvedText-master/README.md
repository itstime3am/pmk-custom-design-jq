fabric.curvedText
=================

Allows you to create text that can be curved

This is an extension for fabric.js (https://github.com/kangax/fabric.js - http://fabricjs.com)

A demo can be seen here:
 - http://jsfiddle.net/EffEPi/qpJTz/
