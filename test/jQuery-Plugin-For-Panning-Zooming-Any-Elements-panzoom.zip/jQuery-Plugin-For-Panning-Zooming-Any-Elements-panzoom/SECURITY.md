# Security Policy

## Version

Only the latest version is supported.

## Reporting a Vulnerability

Report vulnerabilities to 4timmywil@gmail.com
